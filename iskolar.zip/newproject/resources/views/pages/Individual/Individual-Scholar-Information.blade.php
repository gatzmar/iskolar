@extends('layouts.user')
@section('content')


<div class="container">
  <div class="row vertical-offset-100">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-body">
          <div class="thumb">
            <a class="thumbnail" href="#">
              <img class="img-responsive" src="assets/img/avatar.png" alt="" draggable="true" ondragstart="drag(event)">
            </a>
          </div>
          <div class="col-sm-12">
            <h4>Personal Information</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Nick Name: </strong> {!! $scho->nname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> City Address: </strong> {!! $scho->caddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age: </strong> {!! $scho->age !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Gender: </strong> {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Email: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact #: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Permanent Address: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Date of Birth: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Place of Birth: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>School Last Attended</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> School Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> School Address: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Course to be Taken: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> School ID: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> General Weighted Average : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Family Background</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Father Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Sibling's : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Mother Namer : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Character Reference</h4><br>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-sm-12">
            <h4><!-- Family Background --></h4><br>
            <div class="col-sm-12">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Tell About Your Self : </strong><br> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Where do you hear about us? </strong><br> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Why do you apply for this Scholarship? </strong><br> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


@stop