@extends('layouts.master')
@section('content')

<style type="text/css">
	body{
		background: url(../../assets/img/back.png);
		background-color: #444;
		background: url(../../assets/img/pinlayer2.png),url(../../assets/img/pinlayer1.png),url(../../assets/img/back.png);    
	}

	.vertical-offset-100{
		padding-top:5%;
		padding-bottom: 5%;
	}
</style>
@if( Session::has('errors') )
<div class="alert alert‐danger" role="alert" align="center">
	<ul>
		@foreach($errors->all() as $error)
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<li>{{$error}}</li>	
						</div>
					</div>
				</div>
			</div>
		</div>
		@endforeach
	</ul>
</div>
@endif


<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h2 class="panel">Please sign in</h2>

				</div>
				<div class="panel-body">
					<div class="col-sm-12">
						<h4>Personal Information</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">

								{!! Form::open(array('url' => '/Ngo-Registration', 'files'=>true))!!}
								<div class="row">
									<div class="form-group">
										{!! Form::text('ngoname',null,['class'=>'form-control','placeholder'=>'Enter Your Ngo name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('lname',null,['class'=>'form-control','placeholder'=>'Enter The Incharge Last Name']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('fname',null,['class'=>'form-control','placeholder'=>'Enter The Incharge First Name']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('contact',null,['class'=>'form-control','placeholder'=>'Enter The Contact Number']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::email('email',null,['class'=>'form-control','placeholder'=>'Enter Your Email Address']) !!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										{!! Form::text('address',null,['class'=>'form-control','placeholder'=>'Enter Your Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::file('ngologo',null,['class'=>'form‐control']) !!}
									</div>
								</div>
							</div>
						</div>

						<div class="col-sm-12">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										{!! Form::textarea('ngomotto', null, ['class' => 'form-control','size' => '30x5','placeholder'=>'Enter NGO Motto...']) !!}
									</div>
								</div>
							</div>
						</div>

						<div class="col-sm-12">
							<br>
							<h4>Account Information</h4><br>
							<div class="col-sm-12">

								
								<div class="row">
									<div class="form-group">
										{!! Form::text('username',null,['class'=>'form-control','placeholder'=>'Enter Your Username'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::password('password',['class'=>'form-control','placeholder'=>'Enter Your Password'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::password('conpass',['class'=>'form-control','placeholder'=>'Enter Your Rety Password'])!!}
									</div>
								</div>
							</div>
						</div> 
					</div>
					<div class="col-sm-8">
						<a href="/" class="text-center">
							I already have a membership.
						</a><br><br><br>
					</div>
					<div class="col-md-4 pull-right">
						{!! Form::submit('Register',['class' => 'btn btn-block btn-primary btn-lg']) !!}                  
					</div>
				</div>
				{!! Form::close() !!}

			</div>
		</div>
	</div>
</div>

@stop