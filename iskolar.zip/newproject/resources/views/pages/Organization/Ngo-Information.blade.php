@extends('layouts.user')
@section('content')
<br>

<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="thumb">
						<a class="thumbnail" href="#">
							<img class="img-responsive" src="../assets/img/avatar.png" alt="" draggable="true" ondragstart="drag(event)">
						</a>
					</div>
					<div class="col-sm-12">
						<h4>Personal Information</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">

								<div class="row">
									<div class="form-group">
										<strong> Name: </strong> , 
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> Nick Name: </strong> 
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> City Address: </strong> !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> Age: </strong>                  </div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Gender: </strong> 
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="col-sm-12">

									<div class="row">
										<div class="form-group">
											<strong> Email: </strong> , 
										</div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Contact #: </strong> , 
										</div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Permanent Address: </strong> , 
										</div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Date of Birth: </strong> , 
										</div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Place of Birth: </strong> , 
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	@stop