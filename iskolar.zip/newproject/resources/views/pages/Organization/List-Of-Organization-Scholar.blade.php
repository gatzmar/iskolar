@extends('layouts.user')
@section('content')
<br>
<div class="container">
@foreach($list as $lists)
  <div class="col-md-3 col-sm-4">
    <div class="box box-success"><div class="row">
      <div class="panel panel-success scholarpanel">
        <div class="panel-body">
          <div class="media">
            <div class="col-md-12 thumb">
              <a class="thumbnail" href="#">
                <img class="img-responsive" src="{!! $lists->scholarimage !!}" alt="" draggable="true" ondragstart="drag(event)">
              </a>
            </div>
            <div class="media-body">
              <a href="/Organization-Scholar-Information"><h5 class="media-heading"><strong>{!! $lists->lname !!}, {!! $lists->fname !!}</strong></h5></a>
<!--               <p><a href="/Ngo-Information"><h5 class="media-heading"><strong>Name Of Ngo</strong></h5></a>
 -->              </p>
            </div>
<!--             <p><button class="btn btn-info btn-md"><i class="fa fa-plus fa-fw "></i>Add Scholar</button></p>
 -->
           </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endforeach()
</div> 

@stop