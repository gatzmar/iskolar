@extends('layouts.user')
@section('content')
@foreach($user as $users)
<br><br>
<div class="container">
  <div class="row vertical-offset-100">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-body">
            
<div class="col-md-12 ">
  <a class="btn btn-success pull-right" href="/Update-Scholar-Profile/{!! $users->scholar_id !!}">Update Profile  </a><br><br>
</div>
           <div class="col-md-12 thumb">
          <div class="col-md-4 col-md-offset-4">
              <a class="thumbnail" href="#">
                <img class="img-responsive" src="{!! $users->scholarimage !!}" alt="">
              </a>
            </div>
            </div>
          <div class="col-sm-12">
            <h4>Personal Information</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">
<!-- 
                <div class="row">
                  <div class="form-group">
                   <strong> Ngo Name: </strong> {!! $users->lname !!}, {!! $users->lname !!}
                  </div>
                </div> -->
                <div class="row">
                  <div class="form-group">
                   <strong> Name: </strong> {!! $users->lname !!}, {!! $users->fname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Nick Name: </strong> {!! $users->nname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> City Address: </strong> {!! $users->caddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age: </strong> {!! $users->age !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Gender: </strong> {!! $users->gender !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Email: </strong> {!! $users->email !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Permanent Address: </strong> {!! $users->paddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Date of Birth: </strong> {!! $users->birth !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Place of Birth: </strong> {!! $users->pbirth !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4> Last School Attended</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> usersol Name: </strong> {!! $users->sname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> usersol Address: </strong> {!! $users->saddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Course to be Taken: </strong> {!! $users->course !!}
                  </div>  
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> usersol ID: </strong> {!! $users->sid !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> General Weighted Average : </strong> {!! $users->gaverage !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Family Background</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Father Name: </strong> {!! $users->flname !!}, {!! $users->ffname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $users->foccupation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $users->fage !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $users->feducation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Sibling's : </strong> {!! $users->sibling !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Mother Name : </strong> {!! $users->mlname !!}, {!! $users->mfname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $users->moccupation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $users->mage !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $users->meducation !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Character Reference</h4><br>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $users->characterone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $users->charactertwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $users->characterthree !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $users->referenceone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $users->referencetwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $users->referencethree !!}
                  </div>
                </div>
                              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $users->contactone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $users->contacttwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $users->contactthree !!}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-sm-12">
            <h4><!-- Family Background --></h4><br>
            <div class="col-sm-12">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Tell About Your Self : </strong><br> {!! $users->tell !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Where do you hear about us? </strong><br> {!! $users->where !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Why do you apply for this userslarship? </strong><br> {!! $users->why !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endforeach()
<br>

@stop