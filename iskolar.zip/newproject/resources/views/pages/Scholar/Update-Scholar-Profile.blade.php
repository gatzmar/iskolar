@extends('layouts.user')
@section('content')

<style type="text/css">
	body{
		background: url(../../assets/img/back.png);
		background-color: #444;
		background: url(../../assets/img/pinlayer2.png),url(../../assets/img/pinlayer1.png),url(../../assets/img/back.png);    
	}

	.vertical-offset-100{
		padding-top:5%;
		padding-bottom: 5%;
	}
</style>
@if( Session::has('errors') )
<div class="alert alert‐danger" role="alert" align="center">
	<ul>
		@foreach($errors->all() as $error)
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<li>{{$error}}</li> 
						</div>
					</div>
				</div>
			</div>
		</div>
		@endforeach
	</ul>
</div>
@endif

<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">

					{!! Form::open(array('url' => '/Update-Scholar-Profile/'.$scholar->scholar_id, 'files'=>true))!!}
					<div class="col-md-12 thumb">
						<div class="col-md-4 col-md-offset-4">
							<a class="thumbnail" href="#">
								<img class="img-responsive" src="../{!! $scholar->scholarimage !!}" alt="">
							</a>
						</div>
					</div>
					<div class="row">
						<div class="form-group">
							{!! Form::file('scholarimage',null,['class'=>'form‐control']) !!}
						</div>
					</div>
					<div class="col-sm-12">
						<h4>Personal Information</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Last Name:</label>
										{!! Form::text('lname', $scholar->lname ,['class'=>'form-control','placeholder'=>'Enter Your Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Nick Name:</label>
										{!! Form::text('nname', $scholar->nname ,['class'=>'form-control','placeholder'=>'Enter Your Nick Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">City Address:</label>
										{!! Form::text('caddress', $scholar->caddress ,['class'=>'form-control','placeholder'=>'Enter Your City Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('age', $scholar->age ,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class=" form-group">
										<label class="control-label"> 
											Gender: 
										</label>
										<div class="input-group">
											<input type="radio" name="gender" value="female">Female &nbsp&nbsp&nbsp
											<input type="radio" name="gender" value="male">Male 
										</div><!-- /input-group -->
									</div><!-- /.col-lg-6 -->
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Email:</label>
										{!! Form::email('email', $scholar->email ,['class'=>'form-control','placeholder'=>'Enter Your Email'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">First Name:</label>
										{!! Form::text('fname', $scholar->fname ,['class'=>'form-control','placeholder'=>'Enter Your First Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Permanent Address:</label>
										{!! Form::text('paddress', $scholar->paddress ,['class'=>'form-control','placeholder'=>'Enter Your Permanent Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Date of Birth:</label>
										<input type="date" name="birth" class="form-control" value="{!! $scholar->birth !!}">
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Place of Birth:</label>
										{!! Form::text('pbirth', $scholar->pbirth ,['class'=>'form-control','placeholder'=>'Enter Your Place of Birth'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Contact #:</label>
										{!! Form::text('contact', $scholar->contact ,['class'=>'form-control','placeholder'=>'Enter Your Contact Number'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>School Last Attended</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">School Name:</label>
										{!! Form::text('sname', $scholar->sname ,['class'=>'form-control','placeholder'=>'Enter Your School Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">School Address:</label>
										{!! Form::text('saddress', $scholar->saddress ,['class'=>'form-control','placeholder'=>'Enter Your School Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Course to be Taken:</label>
										{!! Form::text('course', $scholar->course ,['class'=>'form-control','placeholder'=>'Enter Your Course to be Taken'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">School ID:</label>
										{!! Form::text('sid', $scholar->sid ,['class'=>'form-control','placeholder'=>'Enter Your School ID'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">General Weighted Average:</label>
										{!! Form::text('gaverage', $scholar->gaverage ,['class'=>'form-control','placeholder'=>'Enter Your General Weighted Average'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>Family Background</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Father Last Name:</label>
										{!! Form::text('flname', $scholar->flname ,['class'=>'form-control','placeholder'=>'Enter Your Father Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Father First Name:</label>
										{!! Form::text('ffname', $scholar->ffname ,['class'=>'form-control','placeholder'=>'Enter Your Father First Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Occupation:</label>
										{!! Form::text('foccupation', $scholar->foccupation ,['class'=>'form-control','placeholder'=>'Enter Your Occupation'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('fage', $scholar->fage ,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Education Attainment:</label>
										{!! Form::text('feducation', $scholar->feducation ,['class'=>'form-control','placeholder'=>'Enter Your Education Attainment'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Sibling's:</label>
										{!! Form::text('sibling', $scholar->sibling ,['class'=>'form-control','placeholder'=>'How many sibling'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Mother Last Name:</label>
										{!! Form::text('mlname', $scholar->mlname ,['class'=>'form-control','placeholder'=>'Enter Your Mother Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Mother First Name:</label>
										{!! Form::text('mfname', $scholar->mfname ,['class'=>'form-control','placeholder'=>'Enter Your Mother first Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Occupation:</label>
										{!! Form::text('moccupation', $scholar->moccupation ,['class'=>'form-control','placeholder'=>'Enter Your Occupation'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('mage', $scholar->mage ,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Education Attainment:</label>
										{!! Form::text('meducation', $scholar->meducation ,['class'=>'form-control','placeholder'=>'Enter Your Education Attainment'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>Character Reference</h4><br>
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Full Name:</label>
										{!! Form::text('characterone', $scholar->characterone ,['class'=>'form-control','placeholder'=>'Enter Your First Character'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('charactertwo', $scholar->charactertwo ,['class'=>'form-control','placeholder'=>'Enter Your Second Character'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('characterthree', $scholar->characterthree ,['class'=>'form-control','placeholder'=>'Enter Your Third Character'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Job:</label>
										{!! Form::text('referenceone', $scholar->referenceone ,['class'=>'form-control','placeholder'=>'Enter Your First Reference'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('referencetwo', $scholar->referencetwo ,['class'=>'form-control','placeholder'=>'Enter Your Second Reference'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('referencethree', $scholar->referencethree ,['class'=>'form-control','placeholder'=>'Enter Your Third Reference'])!!}
									</div>
								</div>
							</div>
						</div>	
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Contact #:</label>
										{!! Form::text('contactone', $scholar-> contactone,['class'=>'form-control','placeholder'=>'Enter Your First Contact Number'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('contacttwo', $scholar-> contacttwo,['class'=>'form-control','placeholder'=>'Enter Your Second Contact Number'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('contactthree', $scholar-> contactthree,['class'=>'form-control','placeholder'=>'Enter Your Third Contact Number'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-12">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Tell About Your Self:</label>	
										{!! Form::textarea('tell',  $scholar->tell , ['class' => 'form-control','size' => '30x5','placeholder'=>'Tell Us About Yourself...']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Where do you hear about us?</label>	
										{!! Form::textarea('where',  $scholar->where , ['class' => 'form-control','size' => '30x5','placeholder'=>'...']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Why do you apply for this Scholarship?</label>	
										{!! Form::textarea('why',  $scholar->why , ['class' => 'form-control','size' => '30x5','placeholder'=>'...']) !!}
									</div>
								</div>

							</div>
						</div>
					</div>
					<div class="col-md-4 pull-right">
						<br><br>
						{!! Form::submit('Update Profile',['class' => 'btn btn-block btn-primary btn-lg']) !!}                  
					</div>
				</div>
				{!! Form::close() !!}

			</div>
		</div>
	</div>
</div>

@stop