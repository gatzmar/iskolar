@extends('layouts.user')
@section('content')

@foreach($user as $users)
<br>
<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="thumb">
						<a class="thumbnail" href="#">
							<img class="img-responsive" src="{!! $users->ngologo !!}" alt="" draggable="true" ondragstart="drag(event)">
						</a>
					</div>
					<div class="col-sm-12">
						<h4>Personal Information</h4><br>
						<div class="col-sm-12">
							<div class="col-sm-12">

								<div class="row">
									<div class="form-group">
										<strong> Ngo Name: </strong>{!! $users->ngoname !!} 
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> Incharge Name: </strong>{!! $users->lname !!}, {!! $users->fname !!} 
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> Contact #: </strong> {!! $users->contact !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<strong> Email: </strong> {!! $users->email !!}         
										        </div>
									</div>
									<div class="row">
										<div class="form-group">
											<strong> Motto: </strong> {!! $users->ngomotto !!}
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-12">
						<br><br>
						<h4>Comments</h4><br>
						<div class="col-sm-12">
							<div class="col-sm-12">

								<div class="row">
									<div class="form-group">
										<strong> Ngo Name: </strong>{!! $users->ngoname !!} 
									</div>
								</div>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endforeach()
              <br><br><br>

	@stop