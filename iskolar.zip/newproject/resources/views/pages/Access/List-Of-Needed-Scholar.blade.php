@extends('layouts.user')
@section('content')
<br>
<div class="container">
@foreach($scholar as $scholars)
  <div class="col-md-3 col-md-4">
  <div class="row">
    <div class="box box-success"><div class="row">
      <div class="panel panel-success scholarpanel">
        <div class="panel-body">
          <div class="media">
            <div class="col-md-12 thumb">
              <a class="thumbnail" href="#">
                <img class="img-responsive" src="{!! $scholars->scholarimage !!}" alt="">
              </a>
            </div>
            <div class="media-body">
              <a href="/Needed-Scholar-Information/{!! $scholars->scholar_id !!}"><h5 class="media-heading"><strong>{!! $scholars->lname !!}, {!! $scholars->fname !!}</strong></h5></a>
              <p>{!! $scholars->course !!}</p>
            </div>
            {!! Form::open(array('url' => '/Add-Request-Scholar'))!!}

            <p>
            {!! Form::hidden('user_id', $value=$scholars->user_id_id)!!}
            {!!Form::submit('Add Scholar',['class'=>'btn btn-info btn-md']) !!}</p>
            {!! Form::close() !!}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

@endforeach
</div> 

@stop