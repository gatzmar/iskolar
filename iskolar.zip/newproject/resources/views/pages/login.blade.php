@extends('layouts.master')
@section('content')
<style type="text/css">
	body{
		background: url(../../assets/img/back.png);
		background-color: #444;
		background: url(../../assets/img/pinlayer2.png),url(../../assets/img/pinlayer1.png),url(../../assets/img/back.png);    
	}

	.vertical-offset-100{
		padding-top:5%;
		padding-bottom: 5%;
	}
</style>	
@if( Session::has('message') )
<div class="alert alert‐success" role="alert" align="center">
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">

{{ Session::get('message') }}</div>
</div>
</div>
</div>
</div>
</div>
@endif
<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-6 col-md-offset-6">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h2 class="panel">Please sign in</h2>
				
				</div>
				<div class="panel-body">
          {!! Form::open(array('url' => '/login'))!!}
						<fieldset>
							<div class="form-group">
            {!! Form::text('username',null,['class'=>'form-control','placeholder'=>'Enter Your Username'])!!}
							</div>
							<div class="form-group">
            {!! Form::password('password',['class'=>'form-control','placeholder'=>'Enter Your Password'])!!} 
							</div>
							
            {!!Form::submit('Login',['class'=>'btn btn-lg btn-success btn-block']) !!}
						</fieldset>
						<div class="form-group">
							<div class="col-md-12 control">
								<br>
								<div class="form-group">
									Don't have an account! <a href="#" data-toggle = "modal" data-target = "#choose" class="text-center" style="text-decoration: none"><strong>Sign Up Here</strong></a>
								</div>             
							</div>
						</div>

                        {!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
</div>
<div class = "modal fade" id = "choose" tabindex = "-1" role = "dialog" aria-labelledby = "myModalLabel" aria-hidden = "true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Choose An Account</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<a href='/NGO-Registration' class="btn btn-lg btn-success btn-block" class="btn btn-success">NGO</a>
				</div> 
				<div class="form-group">
  <a class="btn btn-lg btn-success btn-block" data-toggle="modal" href="#myModal">
    CHOOSE SPONSOR</a>

				</div>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Modal Tittle</h4>
      </div>
			<div class="modal-body">
				<div class="form-group">
					<a href='/Organization-Registration' class="btn btn-lg btn-success btn-block" class="btn btn-success">Organization</a>
				</div> 
				<div class="form-group">
  		<a href='/Individual-Registration' class="btn btn-lg btn-success btn-block" class="btn btn-success">Individual</a>
				</div>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
@stop