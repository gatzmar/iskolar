@extends('layouts.user')
@section('content')
@if( Session::has('message') )
<div class="alert alert‐success" role="alert" align="center">
<div class="container">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-body">

{{ Session::get('message') }}</div>
</div>
</div>
</div>
</div>
</div>
@endif
<br><br>
<div class="container">
      
<div class="col-md-12">
  <a class="btn btn-success" href="/Add-Scholar">
    Add Scholar
  </a><br><br>
</div><br><br>
 @foreach($scholar as $scholars)
<div class="col-md-3 col-sm-4">
  <div class="box box-success">
    <div class="box-body">
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-12">
            <div class="col-md-12 thumb">
              <a class="thumbnail" href="#">
                <img class="img-responsive" src="{!! $scholars->scholarimage !!}" alt="" draggable="true" ondragstart="drag(event)">
              </a>
            </div>
            <div class="col-md-12">
              <h4>Name:{!! $scholars->lname !!}, {!! $scholars->fname !!} </h4>
              <a href="/Scholar-Information/{!! $scholars->scholar_id !!}"><button class="btn btn-success">More Details...</button></a><br><br>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>  
 @endforeach

@stop