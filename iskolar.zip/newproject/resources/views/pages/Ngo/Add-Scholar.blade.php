@extends('layouts.user')
@section('content')

<style type="text/css">
	body{
		background: url(../../assets/img/back.png);
		background-color: #444;
		background: url(../../assets/img/pinlayer2.png),url(../../assets/img/pinlayer1.png),url(../../assets/img/back.png);    
	}

	.vertical-offset-100{
		padding-top:5%;
		padding-bottom: 5%;
	}
</style>
@if( Session::has('errors') )
<div class="alert alert‐danger" role="alert" align="center">
    <ul>
        @foreach($errors->all() as $error)
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <li>{{$error}}</li> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </ul>
</div>
@endif

<div class="container">
	<div class="row vertical-offset-100">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">

					{!! Form::open(array('url' => '/Add-Scholar'))!!}
					<div class="col-sm-12">
						<h4>Personal Information</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Last Name:</label>
										{!! Form::text('lname',null,['class'=>'form-control','placeholder'=>'Enter Your Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Nick Name:</label>
										{!! Form::text('nname',null,['class'=>'form-control','placeholder'=>'Enter Your Nick Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">City Address:</label>
										{!! Form::text('caddress',null,['class'=>'form-control','placeholder'=>'Enter Your City Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('age',null,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class=" form-group">
										<label class="control-label"> 
											Gender: 
										</label>
										<div class="input-group">
											<input type="radio" name="gender" value="female">Female &nbsp&nbsp&nbsp
											<input type="radio" name="gender" value="male">Male 
										</div><!-- /input-group -->
									</div><!-- /.col-lg-6 -->
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Email:</label>
										{!! Form::email('email',null,['class'=>'form-control','placeholder'=>'Enter Your Email'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">First Name:</label>
										{!! Form::text('fname',null,['class'=>'form-control','placeholder'=>'Enter Your First Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Permanent Address:</label>
										{!! Form::text('paddress',null,['class'=>'form-control','placeholder'=>'Enter Your Permanent Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Date of Birth:</label>
										<input type="date" name="birth" class="form-control" >
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Place of Birth:</label>
										{!! Form::text('pbirth',null,['class'=>'form-control','placeholder'=>'Enter Your Place of Birth'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Contact #:</label>
										{!! Form::text('contact',null,['class'=>'form-control','placeholder'=>'Enter Your Contact Number'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>School Last Attended</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">School Name:</label>
										{!! Form::text('sname',null,['class'=>'form-control','placeholder'=>'Enter Your School Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">School Address:</label>
										{!! Form::text('saddress',null,['class'=>'form-control','placeholder'=>'Enter Your School Address'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Course to be Taken:</label>
										{!! Form::text('course',null,['class'=>'form-control','placeholder'=>'Enter Your Course to be Taken'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">School ID:</label>
										{!! Form::text('sid',null,['class'=>'form-control','placeholder'=>'Enter Your School ID'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">General Weighted Average:</label>
										{!! Form::text('gaverage',null,['class'=>'form-control','placeholder'=>'Enter Your General Weighted Average'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>Family Background</h4><br>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Father Last Name:</label>
										{!! Form::text('flname',null,['class'=>'form-control','placeholder'=>'Enter Your Father Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Father First Name:</label>
										{!! Form::text('ffname',null,['class'=>'form-control','placeholder'=>'Enter Your Father First Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Occupation:</label>
										{!! Form::text('foccupation',null,['class'=>'form-control','placeholder'=>'Enter Your Occupation'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('fage',null,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Education Attainment:</label>
										{!! Form::text('feducation',null,['class'=>'form-control','placeholder'=>'Enter Your Education Attainment'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Sibling's:</label>
										{!! Form::text('sibling',null,['class'=>'form-control','placeholder'=>'How many sibling'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Mother Last Name:</label>
										{!! Form::text('mlname',null,['class'=>'form-control','placeholder'=>'Enter Your Mother Last Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Mother First Name:</label>
										{!! Form::text('mfname',null,['class'=>'form-control','placeholder'=>'Enter Your Mother first Name'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Occupation:</label>
										{!! Form::text('moccupation',null,['class'=>'form-control','placeholder'=>'Enter Your Occupation'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Age:</label>
										{!! Form::text('mage',null,['class'=>'form-control','placeholder'=>'Enter Your Age'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Education Attainment:</label>
										{!! Form::text('meducation',null,['class'=>'form-control','placeholder'=>'Enter Your Education Attainment'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<br>
						<h4>Character Reference</h4><br>
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Full Name:</label>
										{!! Form::text('characterone',null,['class'=>'form-control','placeholder'=>'Enter Your First Character'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('charactertwo',null,['class'=>'form-control','placeholder'=>'Enter Your Second Character'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('characterthree',null,['class'=>'form-control','placeholder'=>'Enter Your Third Character'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Job:</label>
										{!! Form::text('referenceone',null,['class'=>'form-control','placeholder'=>'Enter Your First Reference'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('referencetwo',null,['class'=>'form-control','placeholder'=>'Enter Your Second Reference'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('referencethree',null,['class'=>'form-control','placeholder'=>'Enter Your Third Reference'])!!}
									</div>
								</div>
							</div>
						</div>	
						<div class="col-sm-4">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Contact #:</label>
										{!! Form::text('contactone',null,['class'=>'form-control','placeholder'=>'Enter Your First Contact Number'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('contacttwo',null,['class'=>'form-control','placeholder'=>'Enter Your Second Contact Number'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										{!! Form::text('contactthree',null,['class'=>'form-control','placeholder'=>'Enter Your Third Contact Number'])!!}
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-12">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Tell About Your Self:</label>	
										{!! Form::textarea('tell', null, ['class' => 'form-control','size' => '30x5','placeholder'=>'Tell Us About Yourself...']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Where do you hear about us?</label>	
										{!! Form::textarea('where', null, ['class' => 'form-control','size' => '30x5','placeholder'=>'...']) !!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Why do you apply for this Scholarship?</label>	
										{!! Form::textarea('why', null, ['class' => 'form-control','size' => '30x5','placeholder'=>'...']) !!}
									</div>
								</div>

							</div>
						</div>
					</div>

					<div class="col-sm-12">
						<br>
						<h4>Personal Account</h4><br>
						<div class="col-sm-12">
							<div class="col-sm-12">
								<div class="row">
									<div class="form-group">
										<label class="control-label">Username:</label>
										{!! Form::text('username',null,['class'=>'form-control','placeholder'=>'Enter Your Username'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Password:</label>			
										{!! Form::password('password',['class'=>'form-control','placeholder'=>'Enter Your Password'])!!}
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<label class="control-label">Rety Password:</label>	
										{!! Form::password('conpass',['class'=>'form-control','placeholder'=>'Enter Your Rety Password'])!!}
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 pull-right">
						<br><br>
						{!! Form::submit('Register',['class' => 'btn btn-block btn-primary btn-lg']) !!}                  
					</div>
				</div>
				{!! Form::close() !!}

			</div>
		</div>
	</div>
</div>

@stop