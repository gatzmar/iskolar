@extends('layouts.user')
@section('content')
<br><br>
<div class="container">
  <div class="row vertical-offset-100">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-body">
           <div class="col-md-12 thumb">
          <div class="col-md-4 col-md-offset-4">
              <a class="thumbnail" href="#">
                <img class="img-responsive" src="../{!! $scho->scholarimage !!}" alt="">
              </a>
            </div>
            </div>
          <div class="col-sm-12">
            <h4>Personal Information</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Ngo Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Name: </strong> {!! $scho->lname !!}, {!! $scho->lname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Nick Name: </strong> {!! $scho->nname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> City Address: </strong> {!! $scho->caddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age: </strong> {!! $scho->age !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Gender: </strong> {!! $scho->gender !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Email: </strong> {!! $scho->email !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Permanent Address: </strong> {!! $scho->paddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Date of Birth: </strong> {!! $scho->birth !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Place of Birth: </strong> {!! $scho->pbirth !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact #: </strong> {!! $scho->contact !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4> Last School Attended</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> school Name: </strong> {!! $scho->sname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> school Address: </strong> {!! $scho->saddress !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Course to be Taken: </strong> {!! $scho->course !!}
                  </div>  
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> school ID: </strong> {!! $scho->sid !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> General Weighted Average : </strong> {!! $scho->gaverage !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Family Background</h4><br>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Father Name: </strong> {!! $scho->flname !!}, {!! $scho->ffname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $scho->foccupation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $scho->fage !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $scho->feducation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Sibling's : </strong> {!! $scho->sibling !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Mother Name : </strong> {!! $scho->mlname !!}, {!! $scho->mfname !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Occupation : </strong> {!! $scho->moccupation !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Age : </strong> {!! $scho->mage !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Education Attainment : </strong> {!! $scho->meducation !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <h4>Character Reference</h4><br>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->characterone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->charactertwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Full Name: </strong> {!! $scho->characterthree !!}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->referenceone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->referencetwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Job : </strong> {!! $scho->referencethree !!}
                  </div>
                </div>
                              </div>
            </div>
            <div class="col-sm-4">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->contactone !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->contacttwo !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Contact # : </strong> {!! $scho->contactthree !!}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-sm-12">
            <h4><!-- Family Background --></h4><br>
            <div class="col-sm-12">
              <div class="col-sm-12">

                <div class="row">
                  <div class="form-group">
                   <strong> Tell About Your Self : </strong><br> {!! $scho->tell !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Where do you hear about us? </strong><br> {!! $scho->where !!}
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                   <strong> Why do you apply for this scholarship? </strong><br> {!! $scho->why !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<br>

@stop