<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScholarsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{	
		Schema::create('scholars', function(Blueprint $table)
		{
			$table->increments('scholar_id');
			$table->integer('user_id')->unsigned();
			$table->integer('ngo_id')->unsigned();
			$table->string('lname');
			$table->string('nname');
			$table->string('caddress');
			$table->string('age');
			$table->enum('gender',array('male','female'));
			$table->string('email');
			$table->string('fname');
			$table->string('paddress');
			$table->string('birth');
			$table->string('pbirth');
			$table->string('contact');
			$table->string('sname');
			$table->string('saddress');
			$table->string('course');
			$table->string('sid');
			$table->string('gaverage');
			$table->string('flname');
			$table->string('ffname');
			$table->string('foccupation');
			$table->string('fage');		
			$table->string('feducation');
			$table->string('sibling');
			$table->string('mlname');
			$table->string('mfname');
			$table->string('moccupation');
			$table->string('mage');
			$table->string('meducation');
			$table->string('characterone');
			$table->string('charactertwo');
			$table->string('characterthree');
			$table->string('referenceone');
			$table->string('referencetwo');
			$table->string('referencethree');
			$table->string('contactone');
			$table->string('contacttwo');
			$table->string('contactthree');
			$table->string('tell');
			$table->string('where');
			$table->string('why');
			$table->enum('status',array('Available','Not Available'));
			$table->string('scholarimage');
			
			$table->timestamps();
			 $table->foreign('ngo_id')
        ->references('id')
        ->on('users')
        ->onDelete('cascade');
			 $table->foreign('user_id')
        ->references('id')
        ->on('users')
        ->onDelete('cascade');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('scholars');
	}

}
