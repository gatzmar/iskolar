<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSponsorCompTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
				Schema::create('sponsor_comps', function(Blueprint $table)
		{
			$table->increments('company_id');
			$table->string('organizationname');
			$table->string('lname');
			$table->string('fname');
			$table->string('email');
			$table->string('contact');
			$table->string('address');
			$table->string('companylogo');
			$table->string('companymotto',5000);
			$table->string('companybackground',5000);
			$table->integer('user_id')->unsigned();
			
			$table->timestamps();
			 $table->foreign('user_id')
        ->references('id')
        ->on('users')
        ->onDelete('cascade');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('sponsor_comps');
	}

}
