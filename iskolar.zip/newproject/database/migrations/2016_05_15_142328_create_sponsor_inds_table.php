<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSponsorIndsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('sponsor_inds', function(Blueprint $table)
		{
			
			$table->increments('individual_id');
			$table->string('lname');
			$table->string('fname');
			$table->string('birth');
			$table->enum('status',array('married','single','widow'));
			$table->enum('gender',array('male','female'));
			$table->string('email');
			$table->string('contact');
			$table->string('address');
			$table->string('individuallogo');
			$table->string('individualmotto');
			$table->integer('user_id')->unsigned();
			
			$table->timestamps();
			 $table->foreign('user_id')
        ->references('id')
        ->on('users')
        ->onDelete('cascade');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('sponsor_inds');
	}

}
