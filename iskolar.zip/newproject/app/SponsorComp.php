<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class SponsorComp extends Model {

		  protected $primaryKey = 'company_id';
    protected $fillable = ['organizationname','lname','fname','email','contact','address','companylogo','companymotto','companybackground','user_id'];


}
