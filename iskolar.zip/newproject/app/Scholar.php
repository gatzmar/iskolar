<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Scholar extends Model {

	protected $primaryKey = 'scholar_id';
    protected $fillable = ['ngo_id','lname','nname','caddress','age','gender','email','fname','paddress','birth','pbirth','contact','sname','saddress','course','sid','gaverage','flname','ffname','foccupation','fage','feducation','sibling','mlname','mfname','moccupation','mage','meducation','characterone','charactertwo','characterthree','referenceone','referencetwo','referencethree','contactone','contacttwo','contactthree','tell','where','why','status','scholarimage']; 
	
/*
    public function ngo(){
    	return $this->hasMany('App\Ngo', 'bid_id', 'bid_id');
    }*/

}
