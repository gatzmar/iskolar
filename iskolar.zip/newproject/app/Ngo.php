<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Ngo extends Model {

	protected $primaryKey = 'ngo_id';
    protected $fillable = ['ngoname','lname','fname','contact','email','address','ngologo','ngomotto','user_id'];

}
