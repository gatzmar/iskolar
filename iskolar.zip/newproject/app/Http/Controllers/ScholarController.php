<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\User;
use App\Scholar;
use App\addscholar;
use Auth;
use Validator;

class ScholarController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function listrequest()
	{
		$id = Auth::User()->id;
		$user = addscholar::where('scholar_id','=', $id)->get();
		//dd($user);
		//relation ship nila brad ha
		return view('pages.Scholar.List-Of-Sponsor-Requesting');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function profile()
	{
		$id = Auth::User()->id;
		$user = Scholar::where('user_id','=', $id)->get();
    //dd($user);
		return view('pages.Scholar.Scholar-Profile', compact('user'));
	}

	
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function updateprofile($scholar_id)
	{
		$scholar = Scholar::find($scholar_id);

		//dd($scholar);
		return view('pages.Scholar.Update-Scholar-Profile', compact('scholar'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function updateprofilesave(Request $request, $scholar_id){

		$validation = Validator::make($request->all(), [
			
			'lname'			 => 'required',
			'nname'			 => 'required',
			'caddress'		 => 'required',
			'age'			 => 'required|numeric',
			'gender'		 => 'required',
			'email'			 => 'required',
			'fname'			 => 'required',
			'paddress'		 => 'required',
			'birth'			 => 'required',
			'pbirth'		 => 'required',
			'contact'		 => 'required|numeric',
			'sname'			 => 'required',
			'saddress'		 => 'required',
			'course'		 => 'required',
			'sid'			 => 'required',
			'gaverage'		 => 'required',
			'flname'		 => 'required',
			'ffname'		 => 'required',
			'foccupation'	 => 'required',
			'fage'			 => 'required|numeric',
			'feducation'	 => 'required',
			'sibling'		 => 'required|numeric',
			'mlname'		 => 'required',
			'mfname'		 => 'required',
			'moccupation'	 => 'required',
			'mage'			 => 'required|numeric',
			'meducation'	 => 'required',
			'characterone'	 => 'required',
			'charactertwo'	 => 'required',
			'characterthree' => 'required',
			'referenceone'	 => 'required',
			'referencetwo'	 => 'required',
			'referencethree' => 'required',
			'contactone'	 => 'required|numeric',
			'contacttwo'	 => 'required|numeric',
			'contactthree'	 => 'required|numeric',
			'tell'			 => 'required',
			'where'			 => 'required',
			'why'			 => 'required',


			]);
			// Check if it fails //
if( $validation->fails() ){
	return redirect()->back()->withInput()
	->with('errors', $validation->errors() );
}
$scholarc = Scholar::find($scholar_id);

$scholarc->lname	= $request['lname'];
$scholarc->nname	= $request['nname'];
$scholarc->caddress	= $request['caddress'];
$scholarc->age	= $request['age'];
$scholarc->gender	= $request['gender'];
$scholarc->email	= $request['email'];
$scholarc->fname	= $request['fname'];
$scholarc->paddress	= $request['paddress'];
$scholarc->birth	= $request['birth'];
$scholarc->pbirth	= $request['pbirth'];
$scholarc->contact	= $request['contact'];
$scholarc->sname	= $request['sname'];
$scholarc->saddress	= $request['saddress'];
$scholarc->course	= $request['course'];
$scholarc->sid	= $request['sid'];
$scholarc->gaverage	= $request['gaverage'];
$scholarc->flname	= $request['flname'];
$scholarc->ffname	= $request['ffname'];
$scholarc->foccupation	= $request['foccupation'];
$scholarc->fage	= $request['fage'];
$scholarc->feducation	= $request['feducation'];
$scholarc->sibling	= $request['sibling'];
$scholarc->mlname	= $request['mlname'];
$scholarc->mfname	= $request['mfname'];
$scholarc->moccupation	= $request['moccupation'];
$scholarc->mage	= $request['mage'];
$scholarc->meducation	= $request['meducation'];
$scholarc->characterone	= $request['characterone'];
$scholarc->charactertwo	= $request['charactertwo'];
$scholarc->characterthree	= $request['characterthree'];
$scholarc->referenceone	= $request['referenceone'];
$scholarc->referencetwo	= $request['referencetwo'];
$scholarc->referencethree	= $request['referencethree'];
$scholarc->contactone	= $request['contactone'];
$scholarc->contacttwo	= $request['contacttwo'];
$scholarc->contactthree	= $request['contactthree'];
$scholarc->tell	= $request['tell'];
$scholarc->where	= $request['where'];
$scholarc->why	= $request['why'];
$sta = 'Available';
$scholarc->status	= $sta;

// if user choose a file, replace the old one //
if( $request->hasFile('scholarimage') ){
	$scholarimage = $request->file('scholarimage');
	$destination_path = 'Scholar/';

	$filename = str_random(6).'_'.$scholarimage->getClientOriginalName();
	$scholarimage->move($destination_path, $filename);
	$scholarc->scholarimage = $destination_path . $filename;
}


$scholarc->save();
return redirect('/Scholar-Profile')->with('message','Successfully Update!');
}



}
