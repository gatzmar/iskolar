<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class IndividualController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholar()
	{
		return view('pages.organization.List-Of-Individual-Scholar');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholarinfo()
	{
		return view('pages.organization.Individual-Scholar-Information');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function ngoinfo()
	{
		return view('pages.organization.Ngo-Information');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function profile()
	{
		return view('pages.organization.Individual-Profile');
	}



}
