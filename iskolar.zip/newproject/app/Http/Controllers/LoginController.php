<?php namespace App\Http\Controllers;

use Request;
use Redirect;
use App\User;
use Validator;
use Hash;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class LoginController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('pages.login');
	}

 public function login(){
        $request = Request::all();
        // dd($request);
        $username = $request['username'];
        $pass = $request['password'];

        
        if (Auth::attempt(['username' => $username,'password' => $pass])) {
            if(Auth::user()->role == 1){
            return Redirect::intended('/List-Of-Scholar');
            }
            elseif (Auth::user()->role == 2) {
            return Redirect::intended('/List-Of-Needed-Scholar');

            }
            elseif (Auth::user()->role == 3) {
                return Redirect::intended('/List-Of-Needed-Scholar');
            }
          elseif (Auth::user()->role == 4) {
                return Redirect::intended('/List-Of-Sponsor-Requesting');
            }
        
        }
        else{
            return Redirect::to('/')->with('message', 'Something is wrong');
        }

    }
      public function logout(){
        Auth::logout();
        return Redirect::to('/'); 
    }
}
