<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\addscholar;
use App\SponsorComp;
use App\Scholar;
use App\User;
use Auth;
use Redirect;

class OrganizationController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholar()
	{	
		$id = Auth::User()->id;
		$list = Scholar::where('sponsor_id', '=' , $id)->get();
		return view('pages.organization.List-Of-Organization-Scholar', compact('list'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholarinfo($scholar_id)
	{
		$scho = Scholar::find($scholar_id);
		return view('pages.organization.Organization-Scholar-Information', compact('scho'));
	}


	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function ngoinfo()
	{
		return view('pages.organization.Ngo-Information');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function profile()
	{


		$id = Auth::User()->id;
		$user = SponsorComp::where('user_id','=', $id)->get();
		return view('pages.organization.Organization-Profile',compact('user'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function addrequest(Request $request)
	{
		
		$sch = new addscholar;  


		
            $id=Auth::user()->id;
		$sch->scholar_id	= $request['user_id'];
		$sch->user_id	= $id;
		$sch->save();

		return Redirect::to('/List-Of-Needed-Scholar');
	}


}
