<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Scholar;
use Illuminate\Http\Request;

class AccessController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function listAccess()
	{

		$status = 'Available';
        $scholar = Scholar::where('status', '=',$status)->get();
        /*
        $id = */
        //dd($scholar);
		return view('pages.Access.List-Of-Needed-Scholar',compact('scholar'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function infoScholar($scholar_id)
	{
		$scho = Scholar::find($scholar_id);
		return view('pages.Access.Needed-Scholar-Information', compact('scho'));
	}

}
