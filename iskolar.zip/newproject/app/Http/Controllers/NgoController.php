<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Ngo;
use App\User;
use App\Scholar;
use Hash;
use Redirect;
use Auth;
use Validator;
use Illuminate\Http\Request;

class NgoController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function profile()
	{
		$id = Auth::User()->id;
    $user = Ngo::where('user_id','=', $id)->get();
    
		return view('pages.Ngo.Ngo-Profile',compact('user'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function listScholar()
	{

	    $id = Auth::user()->id;
	    $scholar = Scholar::where('ngo_id', '=', $id)->get();
   

	    //dd($scholar);
		return view('pages.Ngo.List-Of-Scholars', compact('scholar'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholarInfo($scholar_id)
	{
		$scho = Scholar::find($scholar_id);
		return view('pages.Ngo.Scholar-Information', compact('scho'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function addscholar()
	{
		return view('pages.Ngo.Add-Scholar');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function scholarsave(Request $request){

		$validation = Validator::make($request->all(), [
			
			'lname'			 => 'required',
			'nname'			 => 'required',
			'caddress'		 => 'required',
			'age'			 => 'required|numeric',
			'gender'		 => 'required',
			'email'			 => 'required',
			'fname'			 => 'required',
			'paddress'		 => 'required',
			'birth'			 => 'required',
			'pbirth'		 => 'required',
			'contact'		 => 'required|numeric',
			'sname'			 => 'required',
			'saddress'		 => 'required',
			'course'		 => 'required',
			'sid'			 => 'required',
			'gaverage'		 => 'required',
			'flname'		 => 'required',
			'ffname'		 => 'required',
			'foccupation'	 => 'required',
			'fage'			 => 'required|numeric',
			'feducation'	 => 'required',
			'sibling'		 => 'required|numeric',
			'mlname'		 => 'required',
			'mfname'		 => 'required',
			'moccupation'	 => 'required',
			'mage'			 => 'required|numeric',
			'meducation'	 => 'required',
			'characterone'	 => 'required',
			'charactertwo'	 => 'required',
			'characterthree' => 'required',
			'referenceone'	 => 'required',
			'referencetwo'	 => 'required',
			'referencethree' => 'required',
			'contactone'	 => 'required|numeric',
			'contacttwo'	 => 'required|numeric',
			'contactthree'	 => 'required|numeric',
			'tell'			 => 'required',
			'where'			 => 'required',
			'why'			 => 'required',


			'password'		 => 'required',
			'username' 		 => 'required',
			]);
// Check if it fails //
		if( $validation->fails() ){
			return redirect()->back()->withInput()
			->with('errors', $validation->errors() );
		}
		$user = new User;
		if ($request['password'] == $request['conpass']) {
			$password = Hash::make($request['password']);
			$user->username = $request['username'];                   
			$user->password = $password;
			$user->role = '4';
			$user->save();
			
		}
$user_id=$user->id;
		
		$scholarc = new Scholar;
		$scholarc->user_id = $user_id;
		
     	$ngo_id=Auth::user()->id;
		$scholarc->ngo_id = $ngo_id;

		$scholarc->lname	= $request['lname'];
		$scholarc->nname	= $request['nname'];
		$scholarc->caddress	= $request['caddress'];
		$scholarc->age	= $request['age'];
		$scholarc->gender	= $request['gender'];
		$scholarc->email	= $request['email'];
		$scholarc->fname	= $request['fname'];
		$scholarc->paddress	= $request['paddress'];
		$scholarc->birth	= $request['birth'];
		$scholarc->pbirth	= $request['pbirth'];
		$scholarc->contact	= $request['contact'];
		$scholarc->sname	= $request['sname'];
		$scholarc->saddress	= $request['saddress'];
		$scholarc->course	= $request['course'];
		$scholarc->sid	= $request['sid'];
		$scholarc->gaverage	= $request['gaverage'];
		$scholarc->flname	= $request['flname'];
		$scholarc->ffname	= $request['ffname'];
		$scholarc->foccupation	= $request['foccupation'];
		$scholarc->fage	= $request['fage'];
		$scholarc->feducation	= $request['feducation'];
		$scholarc->sibling	= $request['sibling'];
		$scholarc->mlname	= $request['mlname'];
		$scholarc->mfname	= $request['mfname'];
		$scholarc->moccupation	= $request['moccupation'];
		$scholarc->mage	= $request['mage'];
		$scholarc->meducation	= $request['meducation'];
		$scholarc->characterone	= $request['characterone'];
		$scholarc->charactertwo	= $request['charactertwo'];
		$scholarc->characterthree	= $request['characterthree'];
		$scholarc->referenceone	= $request['referenceone'];
		$scholarc->referencetwo	= $request['referencetwo'];
		$scholarc->referencethree	= $request['referencethree'];
		$scholarc->contactone	= $request['contactone'];
		$scholarc->contacttwo	= $request['contacttwo'];
		$scholarc->contactthree	= $request['contactthree'];
		$scholarc->tell	= $request['tell'];
		$scholarc->where	= $request['where'];
		$scholarc->why	= $request['why'];
		$sta = 'Update First';
		$image = 'Scholar/IInTSO_avatar2.png';

		$scholarc->status	= $sta;
		$scholarc->scholarimage	= $image;


		$scholarc->save();
		return redirect('/List-Of-Scholar')->with('message','Successfully Create!');
	}

}