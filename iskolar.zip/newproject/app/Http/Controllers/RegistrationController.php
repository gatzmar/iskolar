<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Ngo;
use App\User;
use App\SponsorComp;
use App\SponsorInd;
use Hash;
use Redirect;
use Validator;
use Illuminate\Http\Request;

class RegistrationController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function individual()
	{
		return view('pages.Individual');
	}

	public function individualsave(Request $request){

		$validation = Validator::make($request->all(), [
			
			'username' => 'required',
			'password' => 'required',
			'lname' => 'required',
			'fname' => 'required',
			'birth' => 'required',
			'status' => 'required',
			'gender' => 'required',
			'email' => 'required',
			'contact' => 'required|numeric',
			'address' => 'required',
			'individuallogo' => 'required|image|mimes:jpeg,png|min:1|max:250',
			'individualmotto' => 'required',
			]);
// Check if it fails //
		if( $validation->fails() ){
			return redirect()->back()->withInput()
			->with('errors', $validation->errors() );
		}
		$user = new User;
		if ($request['password'] == $request['conpass']) {
			$password = Hash::make($request['password']);
			$user->username = $request['username'];                   
			$user->password = $password;
			$user->role = '3';
			$user->save();
			
		}

		$company = new SponsorInd;
		$individuallogo = $request->file('individuallogo');
		$destination_path = 'Individual/';
		$filename = str_random(6).'_'.$individuallogo->getClientOriginalName();
		$individuallogo->move($destination_path, $filename);

		$user_id=$user->id;
		
		$company->lname = $request['lname'];
		$company->fname = $request['fname'];
		$company->birth = $request['birth'];
		$company->status = $request['status'];
		$company->gender = $request['gender'];
		$company->email = $request['email'];
		$company->contact = $request['contact'];
		$company->address = $request['address'];
		$company->individuallogo = $destination_path . $filename;
		$company->individualmotto = $request['individualmotto'];
		$company->user_id = $user_id;

		$company->save();
		return redirect('/login')->with('message','Successfully Create!');

	}
	public function organization(){
		return view('pages.Organization');
	}
	public function organizationsave(Request $request){

		$validation = Validator::make($request->all(), [
			
			'username' => 'required',
			'password' => 'required',
			'organizationname' => 'required',
			'lname' => 'required',
			'fname' => 'required',
			'email' => 'required',
			'contact' => 'required|numeric',
			'address' => 'required',
			'companylogo' => 'required|image|mimes:jpeg,png|min:1|max:250',
			'companymotto' => 'required',
			'companybackground' => 'required',
			]);
// Check if it fails //
		if( $validation->fails() ){
			return redirect()->back()->withInput()
			->with('errors', $validation->errors() );
		}
		$user = new User;
		if ($request['password'] == $request['conpass']) {
			$password = Hash::make($request['password']);
			$user->username = $request['username'];                   
			$user->password = $password;
			$user->role = '2';
			$user->save();
			
		}

		$company = new SponsorComp;
		$companylogo = $request->file('companylogo');
		$destination_path = 'Company/';
		$filename = str_random(6).'_'.$companylogo->getClientOriginalName();
		$companylogo->move($destination_path, $filename);

		$user_id=$user->id;
		
		$company->organizationname = $request['organizationname'];
		$company->lname = $request['lname'];
		$company->fname = $request['fname'];
		$company->email = $request['email'];
		$company->contact = $request['contact'];
		$company->address = $request['address'];
		$company->companylogo = $destination_path . $filename;
		$company->companymotto = $request['companymotto'];
		$company->companybackground = $request['companybackground'];
		$company->user_id = $user_id;

		$company->save();
		return redirect('/login')->with('message','Successfully Create!');

	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function ngo()
	{
		return view('pages.ngo');
	}

	public function ngosave(Request $request)
	{

		$validation = Validator::make($request->all(), [
			
			'email' => 'required',
			'username' => 'required',
			'password' => 'required',
			'ngoname' => 'required',
			'lname' => 'required',
			'fname' => 'required',
			'contact' => 'required|numeric',
			'address' => 'required',
			'ngologo' => 'required|image|mimes:jpeg,png|min:1|max:250',
			'ngomotto' => 'required',
			]);
// Check if it fails //
		if( $validation->fails() ){
			return redirect()->back()->withInput()
			->with('errors', $validation->errors() );
		}
		$user = new User;
		if ($request['password'] == $request['conpass']) {
			$password = Hash::make($request['password']);        
			$user->username = $request['username'];                   
			$user->password = $password;
			$user->role = '1';
			$user->save();
			
		}

		$ngo = new Ngo;
		$ngologo = $request->file('ngologo');
		$destination_path = 'Ngo/';
		$filename = str_random(6).'_'.$ngologo->getClientOriginalName();
		$ngologo->move($destination_path, $filename);

		$user_id=$user->id;
		
		$ngo->ngoname = $request['ngoname'];
		$ngo->lname = $request['lname'];
		$ngo->fname = $request['fname'];
		$ngo->contact = $request['contact'];
		$ngo->email = $request['email'];           
		$ngo->address = $request['address'];
		$ngo->ngologo = $destination_path . $filename;
		$ngo->ngomotto = $request['ngomotto'];
		$ngo->user_id = $user_id;

		$ngo->save();
		return redirect('/login')->with('message','Successfully Create!');
	}
}
