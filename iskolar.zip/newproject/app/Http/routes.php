<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*Route::get('/', 'WelcomeController@index');

Route::get('home', 'HomeController@index');

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
*/
Route::get('/','HomeController@index');
Route::get('/NGO-Registration','RegistrationController@ngo');
Route::post('/Ngo-Registration','RegistrationController@ngosave');

Route::get('/Organization-Registration','RegistrationController@organization');
Route::post('/Organization-Registration','RegistrationController@organizationsave');

Route::get('/Individual-Registration','RegistrationController@individual');
Route::post('/Individual-Registration','RegistrationController@individualsave');

Route::get('/login','LoginController@index');
Route::post('/login', 'LoginController@login');
Route::get('/logout', 'LoginController@logout');

/*NGO*/
Route::get('/List-Of-Scholar','NgoController@listScholar');
Route::get('/Scholar-Information/{id}','NgoController@scholarInfo');
Route::get('/Add-Scholar','NgoController@addscholar');
Route::post('/Add-Scholar','NgoController@scholarsave');
Route::get('/Ngo-Profile','NgoController@profile');


/*ACCESS*/
Route::get('/List-Of-Needed-Scholar','AccessController@listAccess');
Route::get('/Needed-Scholar-Information/{id}','AccessController@infoScholar');


/*request add sponsor*/
Route::post('/Add-Request-Scholar','OrganizationController@addrequest');


/*organization*/
Route::get('/List-Of-Organization-Scholar','OrganizationController@scholar');
Route::get('/Organization-Scholar-Information/{id}','OrganizationController@scholarinfo');
Route::get('/Ngo-Information','OrganizationController@ngoinfo');
Route::get('/Organization-Profile','OrganizationController@profile');

/*individual*/
Route::get('/List-Of-Individual-Scholar','IndividualController@scholar');
Route::get('/Individual-Scholar-Information','IndividualController@scholarinfo');
Route::get('/Ngo-Information','IndividualController@ngoinfo');
Route::get('/Individual-Profile','IndividualController@profile');

/*scholar*/
Route::get('/List-Of-Sponsor-Requesting','ScholarController@listrequest');
Route::get('/Scholar-Profile','ScholarController@profile');
Route::get('/Update-Scholar-Profile/{id}','ScholarController@updateprofile');
Route::post('/Update-Scholar-Profile/{id}','ScholarController@updateprofilesave');
