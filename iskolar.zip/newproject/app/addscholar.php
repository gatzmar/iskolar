<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class addscholar extends Model {

		protected $primaryKey = 'add_id';
    protected $fillable = ['user_id','scholar_id'];


}
