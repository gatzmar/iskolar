<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class SponsorInd extends Model {

protected $primaryKey = 'individual_id';
    protected $fillable = ['lname','fname','birth','status','gender','email','contact','address','individuallogo','individualmotto','user_id'];


}
